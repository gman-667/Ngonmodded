## 2-d physics rogue-lite platformer shooter sidescroller

<p align="center">
  <a href="http://cyclokid.github.io/ngon" target="blank"><img src="https://i.imgur.com/xM2gDVX.png" width="120" alt="N-GON" /></a>
</p>

#### different fork from cyclokid

Hosted site

[Gmans Site](gman-667.github.io/n-gon-personal/)

no audio or sfx
